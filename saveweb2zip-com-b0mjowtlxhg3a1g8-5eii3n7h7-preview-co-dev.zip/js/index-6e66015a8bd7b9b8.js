(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[405],{

/***/ 1476:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


    (window.__NEXT_P = window.__NEXT_P || []).push([
      "/",
      function () {
        return __webpack_require__(6321);
      }
    ]);
    if(false) {}
  

/***/ }),

/***/ 6321:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Home; }
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.3.1/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(2676);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.3.1/node_modules/react/index.js
var react = __webpack_require__(5271);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@14.2.6_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/head.js
var head = __webpack_require__(4822);
var head_default = /*#__PURE__*/__webpack_require__.n(head);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@14.2.6_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/next/router.js
var next_router = __webpack_require__(3461);
;// CONCATENATED MODULE: ./src/components/Logo.tsx


const Logo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "text-xl font-bold text-primary",
        children: "MKGPT"
    });
};
/* harmony default export */ var components_Logo = (Logo);

;// CONCATENATED MODULE: ./src/components/Header.tsx



const Header = ()=>{
    const router = (0,next_router.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "flex justify-between items-center py-4 px-4 sm:px-6 lg:px-8",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "cursor-pointer",
                onClick: ()=>router.push("/"),
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Logo, {})
            })
        })
    });
};
/* harmony default export */ var components_Header = (Header);

// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-slot@1.1.0_@types+react@18.3.12_react@18.3.1/node_modules/@radix-ui/react-slot/dist/index.mjs
var dist = __webpack_require__(1557);
// EXTERNAL MODULE: ./node_modules/.pnpm/class-variance-authority@0.7.0/node_modules/class-variance-authority/dist/index.mjs + 1 modules
var class_variance_authority_dist = __webpack_require__(2808);
// EXTERNAL MODULE: ./src/lib/utils.ts + 2 modules
var utils = __webpack_require__(1814);
;// CONCATENATED MODULE: ./src/components/ui/button.tsx





const buttonVariants = (0,class_variance_authority_dist/* cva */.j)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
            outline: "text-foreground border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2",
            sm: "h-8 rounded-md px-3 text-xs",
            lg: "h-10 rounded-md px-8",
            icon: "h-9 w-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? dist/* Slot */.g7 : "button";
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Comp, {
        className: (0,utils.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    });
});
Button.displayName = "Button";


;// CONCATENATED MODULE: ./src/components/ui/card.tsx



const Card = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("rounded-[calc(var(--radius))] border-border border bg-card text-card-foreground shadow", className),
        ...props
    });
});
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    });
});
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
        ref: ref,
        className: (0,utils.cn)("font-semibold leading-none tracking-tight", className),
        ...props
    });
});
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    });
});
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("p-6 pt-0", className),
        ...props
    });
});
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: (0,utils.cn)("flex items-center p-6 pt-0", className),
        ...props
    });
});
CardFooter.displayName = "CardFooter";


;// CONCATENATED MODULE: ./src/components/ui/input.tsx



const Input = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, type, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
        type: type,
        className: (0,utils.cn)("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    });
});
Input.displayName = "Input";


// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-context@1.1.1_@types+react@18.3.12_react@18.3.1/node_modules/@radix-ui/react-context/dist/index.mjs
var react_context_dist = __webpack_require__(9407);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-use-callback-ref@1.1.0_@types+react@18.3.12_react@18.3.1/node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var react_use_callback_ref_dist = __webpack_require__(116);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-use-layout-effect@1.1.0_@types+react@18.3.12_react@18.3.1/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var react_use_layout_effect_dist = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-primitive@2.0.0_@types+react-dom@18.3.1_@types+react@18.3.12_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/@radix-ui/react-primitive/dist/index.mjs
var react_primitive_dist = __webpack_require__(9939);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@radix-ui+react-avatar@1.1.1_@types+react-dom@18.3.1_@types+react@18.3.12_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/@radix-ui/react-avatar/dist/index.mjs
"use client";

// packages/react/avatar/src/Avatar.tsx






var AVATAR_NAME = "Avatar";
var [createAvatarContext, createAvatarScope] = (0,react_context_dist/* createContextScope */.b)(AVATAR_NAME);
var [AvatarProvider, useAvatarContext] = createAvatarContext(AVATAR_NAME);
var Avatar = react.forwardRef(
  (props, forwardedRef) => {
    const { __scopeAvatar, ...avatarProps } = props;
    const [imageLoadingStatus, setImageLoadingStatus] = react.useState("idle");
    return /* @__PURE__ */ (0,jsx_runtime.jsx)(
      AvatarProvider,
      {
        scope: __scopeAvatar,
        imageLoadingStatus,
        onImageLoadingStatusChange: setImageLoadingStatus,
        children: /* @__PURE__ */ (0,jsx_runtime.jsx)(react_primitive_dist/* Primitive */.WV.span, { ...avatarProps, ref: forwardedRef })
      }
    );
  }
);
Avatar.displayName = AVATAR_NAME;
var IMAGE_NAME = "AvatarImage";
var AvatarImage = react.forwardRef(
  (props, forwardedRef) => {
    const { __scopeAvatar, src, onLoadingStatusChange = () => {
    }, ...imageProps } = props;
    const context = useAvatarContext(IMAGE_NAME, __scopeAvatar);
    const imageLoadingStatus = useImageLoadingStatus(src, imageProps.referrerPolicy);
    const handleLoadingStatusChange = (0,react_use_callback_ref_dist/* useCallbackRef */.W)((status) => {
      onLoadingStatusChange(status);
      context.onImageLoadingStatusChange(status);
    });
    (0,react_use_layout_effect_dist/* useLayoutEffect */.b)(() => {
      if (imageLoadingStatus !== "idle") {
        handleLoadingStatusChange(imageLoadingStatus);
      }
    }, [imageLoadingStatus, handleLoadingStatusChange]);
    return imageLoadingStatus === "loaded" ? /* @__PURE__ */ (0,jsx_runtime.jsx)(react_primitive_dist/* Primitive */.WV.img, { ...imageProps, ref: forwardedRef, src }) : null;
  }
);
AvatarImage.displayName = IMAGE_NAME;
var FALLBACK_NAME = "AvatarFallback";
var AvatarFallback = react.forwardRef(
  (props, forwardedRef) => {
    const { __scopeAvatar, delayMs, ...fallbackProps } = props;
    const context = useAvatarContext(FALLBACK_NAME, __scopeAvatar);
    const [canRender, setCanRender] = react.useState(delayMs === void 0);
    react.useEffect(() => {
      if (delayMs !== void 0) {
        const timerId = window.setTimeout(() => setCanRender(true), delayMs);
        return () => window.clearTimeout(timerId);
      }
    }, [delayMs]);
    return canRender && context.imageLoadingStatus !== "loaded" ? /* @__PURE__ */ (0,jsx_runtime.jsx)(react_primitive_dist/* Primitive */.WV.span, { ...fallbackProps, ref: forwardedRef }) : null;
  }
);
AvatarFallback.displayName = FALLBACK_NAME;
function useImageLoadingStatus(src, referrerPolicy) {
  const [loadingStatus, setLoadingStatus] = react.useState("idle");
  (0,react_use_layout_effect_dist/* useLayoutEffect */.b)(() => {
    if (!src) {
      setLoadingStatus("error");
      return;
    }
    let isMounted = true;
    const image = new window.Image();
    const updateStatus = (status) => () => {
      if (!isMounted) return;
      setLoadingStatus(status);
    };
    setLoadingStatus("loading");
    image.onload = updateStatus("loaded");
    image.onerror = updateStatus("error");
    image.src = src;
    if (referrerPolicy) {
      image.referrerPolicy = referrerPolicy;
    }
    return () => {
      isMounted = false;
    };
  }, [src, referrerPolicy]);
  return loadingStatus;
}
var Root = Avatar;
var Image = AvatarImage;
var Fallback = AvatarFallback;

//# sourceMappingURL=index.mjs.map

;// CONCATENATED MODULE: ./src/components/ui/avatar.tsx




const avatar_Avatar = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Root, {
        ref: ref,
        className: (0,utils.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
        ...props
    });
});
avatar_Avatar.displayName = Root.displayName;
const avatar_AvatarImage = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Image, {
        ref: ref,
        className: (0,utils.cn)("aspect-square h-full w-full", className),
        ...props
    });
});
avatar_AvatarImage.displayName = Image.displayName;
const avatar_AvatarFallback = /*#__PURE__*/ react.forwardRef((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(Fallback, {
        ref: ref,
        className: (0,utils.cn)("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
        ...props
    });
});
avatar_AvatarFallback.displayName = Fallback.displayName;


;// CONCATENATED MODULE: ./src/pages/index.tsx








function Home() {
    const [messages, setMessages] = (0,react.useState)([]);
    const [inputMessage, setInputMessage] = (0,react.useState)("");
    const [isLoading, setIsLoading] = (0,react.useState)(false);
    const [chatHistory, setChatHistory] = (0,react.useState)([]);
    const messagesEndRef = (0,react.useRef)(null);
    const inputRef = (0,react.useRef)(null);
    const scrollToBottom = ()=>{
        var _messagesEndRef_current;
        (_messagesEndRef_current = messagesEndRef.current) === null || _messagesEndRef_current === void 0 ? void 0 : _messagesEndRef_current.scrollIntoView({
            behavior: "smooth"
        });
    };
    (0,react.useEffect)(()=>{
        scrollToBottom();
    }, [
        messages,
        isLoading
    ]);
    (0,react.useEffect)(()=>{
        if (!isLoading) {
            var _inputRef_current;
            (_inputRef_current = inputRef.current) === null || _inputRef_current === void 0 ? void 0 : _inputRef_current.focus();
        }
    }, [
        isLoading
    ]);
    const formatTime = (date)=>{
        return new Intl.DateTimeFormat("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true
        }).format(date);
    };
    const handleSendMessage = async (e)=>{
        e.preventDefault();
        if (!inputMessage.trim()) return;
        const userMessage = inputMessage.trim();
        const timestamp = new Date();
        setMessages((prev)=>[
                ...prev,
                {
                    text: userMessage,
                    isUser: true,
                    timestamp
                }
            ]);
        setInputMessage("");
        setIsLoading(true);
        // Update chat history with user message
        const updatedHistory = [
            ...chatHistory,
            {
                role: "user",
                parts: userMessage
            }
        ];
        try {
            const response = await fetch("/api/chat", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    message: userMessage,
                    history: updatedHistory
                })
            });
            if (!response.ok) {
                throw new Error("Failed to send message");
            }
            const data = await response.json();
            // Update messages and chat history with AI response
            setMessages((prev)=>[
                    ...prev,
                    {
                        text: data.response,
                        isUser: false,
                        timestamp: new Date()
                    }
                ]);
            setChatHistory([
                ...updatedHistory,
                {
                    role: "model",
                    parts: data.response
                }
            ]);
        } catch (error) {
            console.error("Error sending message:", error);
            setMessages((prev)=>[
                    ...prev,
                    {
                        text: "Sorry, there was an error processing your message.",
                        isUser: false,
                        timestamp: new Date()
                    }
                ]);
        }
        setIsLoading(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("title", {
                        children: "MKGPT - AI Chatbot"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("meta", {
                        name: "description",
                        content: "AI Chatbot powered by Google's Gemini"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "bg-background min-h-screen flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Header, {}),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("main", {
                        className: "flex-1 flex flex-col items-center p-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Card, {
                            className: "w-full max-w-3xl min-h-[80vh] flex flex-col shadow-lg",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(CardContent, {
                                className: "flex-1 flex flex-col p-4 gap-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "flex-1 overflow-y-auto pr-4 custom-scrollbar",
                                        style: {
                                            height: "60vh"
                                        },
                                        children: [
                                            messages.length === 0 && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "text-center text-muted-foreground mt-8",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                                        className: "text-2xl font-semibold mb-2",
                                                        children: "Welcome to MKGPT!"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                                        children: "Start a conversation by typing a message below."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "space-y-4",
                                                children: [
                                                    messages.map((message, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex items-start gap-3 ".concat(message.isUser ? "flex-row-reverse" : "flex-row", " mb-6"),
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_Avatar, {
                                                                    className: "w-8 h-8 mt-1",
                                                                    children: message.isUser ? /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_AvatarFallback, {
                                                                        children: "YOU"
                                                                    }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_AvatarFallback, {
                                                                                children: "MK"
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_AvatarImage, {
                                                                                src: "/images/ai-avatar.png"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    className: "flex flex-col ".concat(message.isUser ? "items-end" : "items-start", " max-w-[85%]"),
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                            className: "rounded-2xl px-4 py-2.5 whitespace-pre-wrap break-words shadow-sm\n                            ".concat(message.isUser ? "bg-primary text-primary-foreground rounded-tr-none" : "bg-muted rounded-tl-none border border-border/50"),
                                                                            children: message.text
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                                                            className: "text-xs text-muted-foreground mt-1.5 px-1",
                                                                            children: formatTime(message.timestamp)
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }, index)),
                                                    isLoading && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "flex items-start gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)(avatar_Avatar, {
                                                                className: "w-8 h-8",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_AvatarFallback, {
                                                                        children: "MK"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)(avatar_AvatarImage, {
                                                                        src: "/images/ai-avatar.png"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "flex gap-2 bg-muted rounded-lg px-4 py-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                        className: "w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                        className: "w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                                        className: "w-2 h-2 bg-primary rounded-full animate-bounce"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                        ref: messagesEndRef
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                                        onSubmit: handleSendMessage,
                                        className: "flex gap-2 pt-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(Input, {
                                                ref: inputRef,
                                                value: inputMessage,
                                                onChange: (e)=>setInputMessage(e.target.value),
                                                placeholder: "Type your message...",
                                                className: "flex-1",
                                                disabled: isLoading
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)(Button, {
                                                type: "submit",
                                                disabled: isLoading || !inputMessage.trim(),
                                                className: "px-6",
                                                children: "Send"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4822:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(1727)


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [888,774,179], function() { return __webpack_exec__(1476); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);