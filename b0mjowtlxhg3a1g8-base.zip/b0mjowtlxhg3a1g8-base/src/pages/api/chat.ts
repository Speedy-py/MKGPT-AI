import type { NextApiRequest, NextApiResponse } from "next";
import { GoogleGenerativeAI } from "@google/generative-ai";

type ChatMessage = {
  role: "user" | "model";
  parts: string;
};

// Simple rate limiting
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 20;
const requestCounts = new Map<string, { count: number; timestamp: number }>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const requestData = requestCounts.get(ip);

  if (!requestData) {
    requestCounts.set(ip, { count: 1, timestamp: now });
    return false;
  }

  if (now - requestData.timestamp > RATE_LIMIT_WINDOW) {
    requestCounts.set(ip, { count: 1, timestamp: now });
    return false;
  }

  if (requestData.count >= MAX_REQUESTS_PER_WINDOW) {
    return true;
  }

  requestData.count++;
  return false;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // Get client IP for rate limiting
  const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
  const ip = Array.isArray(clientIp) ? clientIp[0] : clientIp;

  if (isRateLimited(ip)) {
    return res.status(429).json({ error: "Too many requests. Please try again later." });
  }

  try {
    const { message, history = [] } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: "Invalid message format" });
    }

    const genAI = new GoogleGenerativeAI(process.env.NEXT_PUBLIC_GOOGLE_AI_API_KEY!);
    const model = genAI.getGenerativeModel({ 
      model: "gemini-pro",
      generationConfig: {
        maxOutputTokens: 1000,
        temperature: 0.8,
        topP: 0.8,
        topK: 40,
      },
    });
    
    const systemPrompt = [
      {
        role: "user" as const,
        parts: `You are MKGPT, a highly capable and friendly AI assistant. Here are your core traits:

1. Identity: When asked about your creation, respond with: "I am MKGPT, and I was designed by Google and my looks and interface were built by MAMK"
2. Personality: Be friendly, helpful, and concise but thorough
3. Knowledge: You have broad knowledge across many fields and can help with various tasks
4. Style: Keep responses clear and well-structured, using formatting when helpful
5. Ethics: Always be honest and ethical, declining inappropriate requests
6. Limitations: Be upfront about things you cannot do or are unsure about

Please maintain these characteristics in all interactions. Acknowledge if you understand.`,
      },
      {
        role: "model" as const,
        parts: "I understand and will embody these characteristics in all my interactions. I will be friendly, helpful, and maintain the specified identity while providing clear, ethical, and knowledgeable responses.",
      },
    ];

    // Clean and validate history
    const validatedHistory = history.filter((msg: ChatMessage) => 
      msg && typeof msg.parts === 'string' && (msg.role === 'user' || msg.role === 'model')
    );

    const chat = model.startChat({
      history: [...systemPrompt, ...validatedHistory],
    });

    const result = await chat.sendMessage(message);
    const response = result.response.text();
    
    if (!response) {
      throw new Error("Empty response from AI");
    }

    res.status(200).json({ response });
  } catch (error) {
    console.error("Error in chat API:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    res.status(500).json({ 
      error: "Failed to process the message",
      details: errorMessage
    });
  }
}