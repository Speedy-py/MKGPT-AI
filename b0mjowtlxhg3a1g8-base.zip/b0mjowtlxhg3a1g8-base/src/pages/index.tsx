import React, { useState, useRef, useEffect } from "react";
import Head from "next/head";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

interface Message {
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface ChatHistory {
  role: "user" | "model";
  parts: string;
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState<ChatHistory[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      inputRef.current?.focus();
    }
  }, [isLoading]);

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(date);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userMessage = inputMessage.trim();
    const timestamp = new Date();
    setMessages(prev => [...prev, { text: userMessage, isUser: true, timestamp }]);
    setInputMessage("");
    setIsLoading(true);

    // Update chat history with user message
    const updatedHistory = [...chatHistory, { role: "user" as const, parts: userMessage }];

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ 
          message: userMessage,
          history: updatedHistory
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to send message");
      }

      const data = await response.json();
      
      // Update messages and chat history with AI response
      setMessages(prev => [...prev, { text: data.response, isUser: false, timestamp: new Date() }]);
      setChatHistory([...updatedHistory, { role: "model" as const, parts: data.response }]);
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, { 
        text: "Sorry, there was an error processing your message.", 
        isUser: false, 
        timestamp: new Date() 
      }]);
    }

    setIsLoading(false);
  };

  return (
    <>
      <Head>
        <title>MKGPT - AI Chatbot</title>
        <meta name="description" content="AI Chatbot powered by Google's Gemini" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="bg-background min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex flex-col items-center p-4">
          <Card className="w-full max-w-3xl min-h-[80vh] flex flex-col shadow-lg">
            <CardContent className="flex-1 flex flex-col p-4 gap-4">
              <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar" style={{ height: "60vh" }}>
                {messages.length === 0 && (
                  <div className="text-center text-muted-foreground mt-8">
                    <h2 className="text-2xl font-semibold mb-2">Welcome to MKGPT!</h2>
                    <p>Start a conversation by typing a message below.</p>
                  </div>
                )}
                <div className="space-y-4">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex items-start gap-3 ${message.isUser ? "flex-row-reverse" : "flex-row"} mb-6`}
                    >
                      <Avatar className="w-8 h-8 mt-1">
                        {message.isUser ? (
                          <AvatarFallback>YOU</AvatarFallback>
                        ) : (
                          <>
                            <AvatarFallback>MK</AvatarFallback>
                            <AvatarImage src="/images/ai-avatar.png" />
                          </>
                        )}
                      </Avatar>
                      <div 
                        className={`flex flex-col ${message.isUser ? "items-end" : "items-start"} max-w-[85%]`}
                      >
                        <div
                          className={`rounded-2xl px-4 py-2.5 whitespace-pre-wrap break-words shadow-sm
                            ${message.isUser
                              ? "bg-primary text-primary-foreground rounded-tr-none"
                              : "bg-muted rounded-tl-none border border-border/50"
                            }`}
                        >
                          {message.text}
                        </div>
                        <span className="text-xs text-muted-foreground mt-1.5 px-1">
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex items-start gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback>MK</AvatarFallback>
                        <AvatarImage src="/images/ai-avatar.png" />
                      </Avatar>
                      <div className="flex gap-2 bg-muted rounded-lg px-4 py-2">
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>
              <form onSubmit={handleSendMessage} className="flex gap-2 pt-2">
                <Input
                  ref={inputRef}
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1"
                  disabled={isLoading}
                />
                <Button 
                  type="submit" 
                  disabled={isLoading || !inputMessage.trim()}
                  className="px-6"
                >
                  Send
                </Button>
              </form>
            </CardContent>
          </Card>
        </main>
      </div>
    </>
  );
}