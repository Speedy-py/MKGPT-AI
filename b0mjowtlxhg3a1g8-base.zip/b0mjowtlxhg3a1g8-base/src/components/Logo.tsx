import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="text-xl font-bold text-primary">MKGPT</div>
  );
};

export default Logo;